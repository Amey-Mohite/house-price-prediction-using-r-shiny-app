1. Unzip the zip file.
2. install packages given in app.R file
3. open all the three .R files in Rstudio 
4. go to ui.R and click  on run app.